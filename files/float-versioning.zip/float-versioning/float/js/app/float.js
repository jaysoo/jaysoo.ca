define(['cs!./csmain'], function (Float) {
  'use strict';
  return Float;
});
