// Configure custom paths to vendor modules.
require.config({
  paths: {
    // RequireJS
    text: '../components/requirejs-text/text',
    domReady: '../components/requirejs-domready/domReady',
    cs: '../components/require-cs/cs',
    'coffee-script': '../components/require-cs/coffee-script',
    json: '../components/requirejs-plugins/src/json',

    // Date parsing
    moment: '../components/moment/moment',

    // Twitter bootstrap
    bootstrap: '../vendor/twitter/bootstrap',

    // jQuery and plugins
    jquery: '../components/jquery/jquery.min',
    jquery_ui: '../vendor/jquery_ui/jquery-ui.min',
    jquery_minicolors: '../vendor/jquery.minicolors/jquery.miniColors.amd.min',
    jquery_cookie: '../vendor/jquery.cookie/jquery.cookie.amd',
    pnotify: '../components/pines-notify/jquery.pnotify',

    zcharts: '../vendor/charts/zingchart-html5-min',

    // Better dropdown boxes
    select2: '../components/select2/select2',

    // Number parsing/formatting
    accounting: '../components/accounting/accounting',

    // Utility functions
    underscore: '../components/lodash/lodash',

    // Backbone
    backbone: '../components/backbone-amd/backbone',
    backbone_forms: '../vendor/backbone_forms/backbone-forms',
    backbone_stickit: '../vendor/backbone.stickit/backbone.stickit',

    // Handlebars template
    handlebars: '../vendor/handlebars/handlebars-1.0.0-beta.6.amd',

    // Datepicker
    wave_datepicker: '../components/wave-datepicker/dist/wave-datepicker'
  },

  shim: {
    'jquery': {
      exports: '$'
    },

    'underscore': {
      exports: '_'
    },

    'handlebars': {
      exports: 'Handlebars'
    },

    'bootstrap': {
      deps: ['jquery'],
      exports: '$.fn.popover'
    },

    'jquery_ui': {
      deps: ['jquery'],
      exports: '$.fn.dialog'
    },

    'jquery_cookie': {
      deps: ['jquery'],
      exports: '$.cookie'
    },

    'jquery_minicolors': {
      deps: ['jquery'],
      exports: '$.fn.miniColors'
    },

    'select2': {
      deps: ['jquery'],
      exports: '$.fn.select2'
    },

    'pnotify': {
      deps: ['jquery'],
      exports: '$.pnotify'
    },


    'wave_datepicker': {
      deps: ['jquery'],
      exports: '$.fn.datepicker'
    }
  }
});
