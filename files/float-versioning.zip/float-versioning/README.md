# Float -- the Wave frontend framework

**Float** is the frontend framework for use with all Wave properties, and contains all the necessary reusable or shared elements (buttons, alert messages, icons, boxes, etc). It is based heavily on Twitter's [bootstrap](http://twitter.github.com/bootstrap/), but since (a) we do not need or want to include the entirety of bootstrap in our projects, and (b) we have customized elements of bootstrap considerably, we treated bootstrap as merely a set of sane defaults for LESS, rather than attempting to fork it or keep up with new releases. As such, bootstrap's documentation, while potentially helpful, should not be considered the canonical resource for Float.

Getting Started
---------------

You will need [NodeJS](http://nodejs.org/) (0.8+) installed on your machine. (`node --version` to check your installed version).

**Note**: If you have Grunt installed previously, you will need to uninstall it first:

    sudo npm uninstall -g grunt

Now, install grunt-cli and bower:

    sudo npm install -g bower grunt-cli@latest

Make sure that you add the npm bin directory to your PATH in `.bashrc`:

    # Sample path if npm installed through Homebrew
    export PATH="/usr/local/share/npm/bin:$PATH"


Installing/Updating dependencies
--------------------------------

These commands will update both NodeJS and client-side dependences. The latter probably changes more often.

Install NodeJS dependencies:

    npm install

Install client-side JavaScript components:

    bower install


Building
--------

Using grunt:

    grunt build

This will create a dist folder with the files ready for use in your project.

Testing
-------

1) Using PhantomJS:

    grunt test


2) In browser:

    grunt connect:test

Then browse to [http://localhost:9001/test/index.html](http://localhost:9001/test/index.html).

Development
-----------

You can run the development server using the `grunt` command. This will start a server on port 9001, and the root is the root of the project.

e.g. http://localhost:9001/example/

Any stylesheet changes will live-reload the page so you don't need manual refreshes.

Documentation
-------------

Live documentation for Float can be viewed online at <http://wave-float.herokuapp.com/>. This documentation is generated dynamically by a node.js app in the `docs` directory; it takes the Float LESS files and processes them to output CSS, and builds a page by reading a collection of pattern files, which are the individual snippets of HTML used to create each element. See `docs/pattern-primer.js` for more info.

To run the documentation app locally, ensure you have `connect` installed (`sudo npm install -g connect`) and then from the top of the repository:

    $ node docs/pattern-primer.js

This will make the documentation available at [http://localhost:8001/](http://localhost:8001).

TODO: info on deploying to heroku, or relocate docs elsewhere


Updating Float itself
---------------------

So you have a need to update or customize some of the styling that Float is providing. There are three choices available to you. In order of preference:

1. **Modify your use-case** to fit what Float provides. Float is fairly flexible, so while you may not end up with what you envisioned, there is a chance that you can achieve something workable to solve your problem with what it provides already. Float is not infinitely flexible, obviously, so you might argue for skipping to authoring new CSS -- but indeed the point of a framework is to force us to adhere to a common middle ground.
1. **Write an override** in custom.less. The custom.less file is meant to be for the truly one-off specific components of your site that are not reusable, but it can also be used for overrides. However, if a lot of overrides pile up, this is (a) hard to read and maintain, and (b) probaby indicative of more global changes that need to be made. So while this option is easy to do, please consider carefully.
1. **Update Float** itself. This framework is by no means perfect, so changes will need to be made and bugs will need to be fixed. However, again we need to consider carefully what we add. Everything in Float should be "app-agnostic" and able to be shared amongst *all* Wave properties. If we add one-app only things, or things that are not used very often, we end up with bloat that will affect all projects.

If you do have the need to update Float, we will do something like the following (this process is still TBD as we sort out the details):

1. Update the LESS files with whatever changes are required. You can do this by modifying the LESS files in the Float repo and using the documentation to see how it renders (see above). Or you can do it by modifying the LESS files directly from inside your project. But if you choose this route, as per above, you don't want to *just* change your project; you want to add those changes back to Float and follow the rest of this process.
1. Update Float's documentation as necessary, for example by adding or updating pattern snippets.
1. Commit all changes to Float repo.
1. Make a new tag/version.
1. Push to Github so code is available.
1. Push to Heroku to update live documentation.
1. Notify developers somehow that a new release is available.
1. You (or another developer) checks out the new Float, copies the new files into project, and commits that result.
