/*jslint nomen: true */
//'use strict';

var settings = {
    default_webserverport : '8001',
    docs_root: 'docs/public/',
    framework_images_dir: 'float/images/',
    framework_less_dir: 'float/less/',
    toc_filename: 'toc.js',
    source_html_filename: 'source.html',
    less_filename: 'wave.less',
    static_css_filename: 'wave.css'
  },

  // various paths
  tocFile = settings.docs_root + settings.toc_filename,
  sourceHtmlFile = settings.docs_root + settings.source_html_filename,
  patternFolder = settings.docs_root + "patterns/",
  lessFile = settings.framework_less_dir + "/" + settings.less_filename,
  staticDir = settings.docs_root + "static/",
  staticFloatImagesDir = staticDir + "float/images/",
  staticFloatCssDir = staticDir + "float/css/",
  staticFloatCssFile = staticFloatCssDir + settings.static_css_filename,
  frameworkImagesDir = settings.framework_images_dir,

  // port
  serverPort = process.env.PORT || settings.default_webserverport,

  // requires
  util = require('util'),
  fs = require('fs'),
  connect = require('connect'),
  exec = require('child_process').exec,
  wrench = require('wrench'),


  //
  // Main function to handle creating the HTML output
  //
  primer = function (serverResponse) {

    var simpleEscaper = function (text) {
        return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
      },

      //
      // Render the HTML for the navigation structure based on the TOC sections.
      //
      renderNav = function (toc) {
        var html = '<nav><ul>',
            i, l,
            title;

        for (var i = 0, l = toc.length; i < l; i++) {
          title = toc[i].title;
          html += '<li><a href="#' + title.toLowerCase().replace(" ", "-") + '">' + title + '</a></li>';
        }
        html += '</ul></nav>';

        return html;
      },


      //
      // Render the HTML for a section of documentation. Reads each entry in
      // the TOS and looks for the associated pattern snippet file. Note there
      // are explicit CSS class names on some elements to avoid collisions with
      // the live site CSS itself we are documenting (more may be required;
      // edit below as necessary).
      //
      renderSection = function (section) {
        var html = "",
          i, l,
          item,
          pattern;

        html += '<section id="' + section.title.toLowerCase().replace(" ", "-") + '">';
        html += '<h1>' + section.title + '</h1>';
        if ((section.description !== undefined) && (section.description !== "")) {
          html += '<p class="float-text">' + section.description + '</p>';
        }

        for (i = 0, l = section.entries.length; i < l; i += 1) {
          item = section.entries[i];

          if ((item.filename === undefined) || (item.filename === "")) {
            util.puts('There was an error when trying to read file:', item.filename);
            return;
          }

          try {
            pattern = fs.readFileSync(patternFolder + '/' + item.filename, 'utf-8');
          } catch (e) {
            util.puts('There was an error when trying to read file:', item.filename);
            return;
          }

          html += '<div class="float-pattern">';
          if ((item.title !== undefined) && (item.title !== "")) {
            html += '<h2>' + item.title + '</h2>';
          }
          if ((item.description !== undefined) && (item.description !== "")) {
            html += '<p class="float-text">' + item.description + '</p>';
          }
          html += '<div class="float-display">' + pattern + '</div>';
          html += '<div class="float-source"><pre>' + simpleEscaper(pattern) + '</pre></div>';
          html += '</div>';
          html += '<hr>';
        }

        html += '</section>';

        return html;
      },

      //
      // Render the main body of the documentation: open the source file (ie
      // head of the document), create the nav, loop over each section in the
      // TOS, and close the page. Then finish up by sending the content to the
      // server.
      //
      outputPatterns = function (toc) {
        fs.readFile(sourceHtmlFile, 'utf-8', function (err, content) {
          if (err !== null) {
            util.puts('There was an error when trying to read file:', sourceHtmlFile);
            return;
          }

          content += renderNav(toc);

          for (var i = 0, l = toc.length; i < l; i++) {
            content += renderSection(toc[i]);
          }

          content += '<footer></footer></body></html>';

          serverResponse.end(content);
        });
      },


      //
      // Start the entire process: check that the necessary source files exist,
      // and output the patterns HTML.
      //
      beginProcess = function () {
        fs.readdir(patternFolder, function (err, contents) {
          if (err !== null && err.code === 'ENOENT') {
            util.puts('Cannot find patterns folder:', patternFolder);
            return;
          }

          fs.readFile(tocFile, "utf-8", function (err, contents) {
            if (err !== null && err.code === 'ENOENT') {
              util.puts('Cannot find table of contents file:', tocFile);
              return;
            }

            var toc = JSON.parse(contents.toString("utf-8"));
            outputPatterns(toc);
          });
        });
      };

    // And away we go
    beginProcess();
  },

  // Create a server
  server = connect()
    .use(connect.logger('dev'))
    .use(connect.static(staticDir))
    .use(function (req, res) {
      primer(res);
    });


// The main static/float directory exists, but the css and images
// subdirectories do not, so create them first
wrench.mkdirSyncRecursive(staticFloatCssDir, 0777);
util.puts('Created static dir for float css: ' + staticFloatCssDir);
wrench.mkdirSyncRecursive(staticFloatImagesDir, 0777);
util.puts('Created static dir for float images: ' + staticFloatImagesDir);


// Copy the framework image files from their organized location to where they
// can be served
wrench.copyDirSyncRecursive(frameworkImagesDir, staticFloatImagesDir);
util.puts('Finished copying framework image files.');

// Compile the framework LESS files from their organized location to a CSS
// file that can be served
exec('lessc ' + lessFile, function (error, stdout, stderr) {
  if (error !== null) {
    util.puts('exec error: ' + error);
    return;
  }
  fs.writeFile('./' + staticFloatCssFile, stdout, 'utf-8', function () {
    util.puts('Finished compiling LESS and writing to output CSS file.');

    // Finally, kick off the server
    server.listen(serverPort);
    util.puts('Server running. Visit http://localhost:' + serverPort + '/ to see your documentation.');
    util.puts('To kill this server, press Ctrl + C');
  });
});
