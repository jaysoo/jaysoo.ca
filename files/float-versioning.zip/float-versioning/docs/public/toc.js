[

  {
    "title": "Colour",
    "description": "",
    "entries": [
      {
        "title": "Palette",
        "description": "These are the colours you get to use, and their hex and LESS definitions.",
        "filename": "colour.html"
      }
    ]
  },


  {
    "title": "Typography",
    "description": "Treatments for various text entities. Note we only document our non-default typographic styles that require CSS classes, not for example how we've styled an un-modified <code>&lt;p&gt;</code>.",
    "entries": [
      {
        "title": "Body text",
        "description": "For text longer than a sentence that is meant to be read, for example a set of instructions or an explanation of what something is.",
        "filename": "typography-body-text.html"
      },
      {
        "title": "Introduction text",
        "description": "Use sparingly for a large introductory or teaser paragraph.",
        "filename": "typography-intro-text.html"
      },
      {
        "title": "Coloured text",
        "description": "",
        "filename": "typography-coloured-text.html"
      }
    ]
  },


  {
    "title": "Icons",
    "description": "",
    "entries": [
      {
        "title": "Small icons",
        "description": "Provide a context hint for actions. The <code>&lt;i&gt;</code> element can be inserted into almost any container, but are primarily for inside buttons.",
        "filename": "icons-small.html"
      },
      {
        "title": "Medium monochrome icons",
        "description": "Provide a context hint for subheads.",
        "filename": "icons-medium.html"
      },
      {
        "title": "Large coloured icons",
        "description": "Provide a context hint for page titles.",
        "filename": "icons-large.html"
      }
    ]
  },


  {
    "title": "Boxes",
    "description": "Various boxes and containers for content.",
    "entries": [
      {
        "title": "Coloured box",
        "description": "Gray and blue are the primary coloured boxes to use. Yellow is used for boxes that serve as alerts (but not <em>actual</em> alerts; see the alerts component).",
        "filename": "box-coloured.html"
      },
      {
        "title": "Box with header and footer",
        "description": "Boxes can have optional header and footer elements inside them.",
        "filename": "box-header-footer.html"
      },
      {
        "title": "Notice box",
        "description": "Odd box used if you want to draw particular attention to it. The components need custom background colours defined (not inline obviously) depending on where the box is put.",
        "filename": "box-notice.html"
      }
    ]
  },


  {
    "title": "Alerts",
    "description": "Alerts are the info boxes that appear as feedback after the user takes an action.",
    "entries": [
      {
        "title": "Info",
        "description": "Provide basic information.",
        "filename": "alert-info.html"
      },
      {
        "title": "Warning",
        "description": "Notify of a potentially dangerous, unexpected, or non-obvious situation.",
        "filename": "alert-warning.html"
      },
      {
        "title": "Error",
        "description": "Notify of an error or other task-stopping event (eg form invalidation).",
        "filename": "alert-error.html"
      },
      {
        "title": "Success",
        "description": "Notify of an event completing successfully (eg save confirmation).",
        "filename": "alert-success.html"
      },
      {
        "title": "Alert with more content",
        "description": "If your alert message is longer than a simple string, you can add markup for improved styling.",
        "filename": "alert-extras.html"
      }
    ]
  },


  {
    "title": "Buttons",
    "description": "We use only one size of traditional button, which are used for primary actions only. Note that all button CSS classes can be applied to <code>&lt;a&gt;</code>, <code>&lt;input&gt;</code> or <code>&lt;button&gt;</code> elements.",
    "entries": [
      {
        "title": "Generic Buttons",
        "description": "The default unstyled version. Use whenever one of the explicitly styled versions below doesn't make sense.",
        "filename": "button-generic.html"
      },
      {
        "title": "Success button",
        "description": "Button denoting the positive action. Used for form submissions, saving, 'yes' actions, etc.",
        "filename": "button-success.html"
      },
      {
        "title": "Success button with canceler",
        "description": "Used where it's assumed the primary action is by far likely to be the obvious default choice (for example, a form submission) rather than two yes/no buttons, which implies equal weighting.",
        "filename": "button-success-with-cancel.html"
      },
      {
        "title": "Error button",
        "description": "Button denoting the negative action. Used for cancelling, deleting, 'no' actions, etc.",
        "filename": "button-error.html"
      },
      {
        "title": "Disabled button",
        "description": "Button in its disabled state. Used to show either that a button exists but its action is not (yet) valid, or eg. after a form submission, to provide a visual hint not to click a submit button again.",
        "filename": "button-disabled.html"
      },
      {
        "title": "Button groups",
        "description": "Buttons can be grouped together in a row by wrapping them in a container element. Use only when all buttons are directly related to each other.",
        "filename": "button-group.html"
      },
      {
        "title": "Small button",
        "description": "Minimal text-only button used for functionality that is optional, secondary, or for convenience to the primary action of the page. Should be accompanied by an icon to distinguish from a plain link.",
        "filename": "button-small.html"
      }
    ]
  },

  {
    "title": "Labels",
    "entries": [
      {
        "title": "Default labels",
        "description": "",
        "filename": "labels-default.html"
      },
      {
        "title": "Status labels",
        "description": "Same colours/styling as above, but with name aliases that correspond to invoice statuses.",
        "filename": "labels-status.html"
      }
    ]
  },

  {
    "title": "Tables",
    "description": "All tables get the <code>table</code> class, but the remaining styling can be mixed and matched to achieve the desired effect. Ensure all table HTML is well-formed, with eg. <code>thead</code> and <code>tbody</code> sections.",
    "entries": [
      {
        "title": "Vanilla table",
        "description": "Default styling.",
        "filename": "table-default.html"
      },
      {
        "title": "Condensed table",
        "description": "Provides a little tighter spacing in the cells.",
        "filename": "table-condensed.html"
      },
      {
        "title": "Bordered table",
        "description": "Provides a coloured header row and borders.",
        "filename": "table-bordered.html"
      },
      {
        "title": "Striped table",
        "description": "Provides zebra-striping on the rows.",
        "filename": "table-striped.html"
      },
      {
        "title": "Hoverable table",
        "description": "Provides mild highlighting on row hovers. To disable highlighting on specific rows, use the <code>no-hoverable</code> class.",
        "filename": "table-hoverable.html"
      },
      {
        "title": "Sortable table",
        "description": "Given links with class <code>asc</code> or <code>desc</code> surrounding the header cell text, provides icons denoting direction of sort. Requires <code>table-bordered</code> for proper colouring. <strong>NOTE</strong>: Actually sorting the table is currently not implemented via Float (ie., do your own AJAX).",
        "filename": "table-sortable.html"
      },
      {
        "title": "Fixed width table",
        "description": "Apply to any table that may contain user-generated content, and add a class of <code>wrappable</code> to those cells, to prevent overflowing content.",
        "filename": "table-fixed-width.html"
      },
      {
        "title": "Fully loaded table",
        "description": "Style all the things!",
        "filename": "table-fully-loaded.html"
      }
    ]
  },

  {
    "title": "Grid",
    "entries": [
      {
        "title": "Fixed grid",
        "description": "In a parent <code>container</code> (940px wide), provides 12 available columns of fixed width. Each column needs to nest inside a parent <code>row</code> class.",
        "filename": "grid-fixed.html"
      },
      {
        "title": "Fixed grid with offset and nesting",
        "description": "Columns can be offset and rows can be nested.",
        "filename": "grid-fixed-offset-nested.html"
      },
      {
        "title": "Fluid grid",
        "description": "Same as above, except column widths are dynamic. Not to be used for pseudo-responsive layouts, but useful eg. for columns inside another element that has an odd width, extra padding, etc.",
        "filename": "grid-fluid.html"
      }
    ]
  }
]
